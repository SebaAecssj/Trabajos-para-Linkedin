$(function(){
    $("#form").validate({
        rules: {
            NOMBRE : {
                required: true,
                minlength: 3
            },
            APELLIDO : {
                required: true,
                minlength: 3
            },
            DIRECCION: {
                required: true,
                minlength: 15
            },
            NUMERO: {
                required: true,
                number: true
            },
            CORREO: {
                required: true,
                email: true
            },
            CONTRASEÑA: {
                required: true,
                minlength: 5
            },
            vCONTRASEÑA: {
                required: true,
                minlength: 5,
                equalTo: "#CONTRASEÑA"
            }
        },
        messages : {
            NOMBRE: {
                required: "Por favor ingrese un nombre",
                minlength: "Este espacio debe tener al menos 3 caracteres."
            },
            APELLIDO: {
                required: "Por favor ingrese un apellido",
                minlength: "Este espacio debe tener al menos 3 caracteres."
            },
            DIRECCION: {
                required: "Por favor ingrese una dirección",
                minlength: "Este espacio debe tener al menos 15 caracteres."
            },
            NUMERO: {
                required: "Por favor digite su número.",
                number: "Por favor digite solo números."
            },
            CORREO: {
                required: "Por favor ingrese un correo",
                email: "El e-mail debe ser del siguiente formato: abc@domain.tld"
            },
            CONTRASEÑA: {
                required: "Por favor ingrese una contraseña",
                minlength: "El largo de la contraseña debe ser de al menos 5 caracteres."
            },
            vCONTRASEÑA: {
                required: "Este campo no puede quedar vacio",
                minlength: "El largo de la contraseña debe ser de al menos 5 caracteres.",
                equalTo: "Por favor ingrese la misma contraseña."
            }
        }
    })
});

$(document).ready(main);
 
var contador = 1;
 
function main(){
	$('.menu_bar').click(function(){
		// $('nav').toggle(); 
 
		if(contador == 1){
			$('nav').animate({
				left: '0'
			});
			contador = 0;
		} else {
			contador = 1;
			$('nav').animate({
				left: '-100%'
			});
		}
 
	});
 
};