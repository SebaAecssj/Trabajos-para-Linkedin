from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto, Marca
from .forms import CustomUserCreationForm, ProductoForm
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.template import RequestContext
import requests
# Create your views here.

def inicio(request):
    return render(request, 'core/inicio.html')

def galeria(request):
    busqueda = request.GET.get("buscar")
    productos = Producto.objects.all()
    if busqueda:
        productos = Producto.objects.filter(
            Q(nombre__icontains = busqueda)
        ).distinct()
    
    return render(request, 'core/galeria.html', {'container': productos})

def registro(request):
    data = {
        'form': CustomUserCreationForm()
    }
    #guardar los datos del registro de usuario y autenticarlo en la pagina
    if request.method == 'POST':
        formulario = CustomUserCreationForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            user = authenticate(username=formulario.cleaned_data['username'], password=formulario.cleaned_data['password1'])
            login(request, user)
            messages.success(request, 'Te has registrado con exito.')
            #redirigir al home
            return redirect(to='inicio')
        data['form'] = formulario

    return render(request,'registration/Registro.html', data)

@permission_required('core.add_producto') #Se requieren permisos de administrador para acceder al url y al menu
def agregar_producto(request):

    data = {
        'form': ProductoForm()
    }
    #agregar producto a la base de datos
    if request.method == 'POST':
        formulario = ProductoForm(data=request.POST, files=request.FILES)
        if formulario.is_valid:
            formulario.save()
            messages.success(request, "Producto agregado con exito")
            #redirigir a la url de 'galeria'
            return redirect(to="galeria")
        else:
            data["form"] = formulario

    return render(request, 'core/agregar.html', data)

@permission_required('app.change_producto')
def modificar_producto(request, id):

    producto = get_object_or_404(Producto, id=id)

    data = {
        'form': ProductoForm(instance=producto)
    }
    #modificar los datos de un producto en la base de datos
    if request.method == 'POST':
        formulario = ProductoForm(data=request.POST, files=request.FILES, instance= producto)
        if formulario.is_valid:
            formulario.save()
            messages.success(request, 'Producto modificado con exito.')
            return redirect(to="galeria")
        data["form"] = formulario    
    return render (request, 'core/modificar.html', data)

@permission_required('app.delete_producto')
def eliminar(request, id):
    #eliminar un producto por medio del id
    producto = get_object_or_404(Producto, id=id)
    producto.delete()
    messages.success(request, 'Producto eliminado con exito.')
    return redirect(to="galeria")
