from django.urls import path
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import LoginView, PasswordResetView, PasswordResetConfirmView, PasswordResetCompleteView
from .views import inicio, galeria, registro, agregar_producto, modificar_producto, eliminar

urlpatterns = [
    #Links para redireccionar a otras paginas
    path('', inicio, name='inicio'),
    path('galeria/', galeria, name='galeria'),
    path('registro/', registro, name='registro'),
    path('agregar/', agregar_producto, name='agregar-producto'),
    path('modificar/<id>/', modificar_producto, name='modificar'),
    path('eliminar/<id>', eliminar, name='eliminar'),

    #Links de reseteo de contraseña
    path('accounts/password_reset/', 
    auth_views.PasswordResetView.as_view(template_name='accounts/reset_password.html'),
    name='password_reset'),
    path('accounts/password_reset/done/', 
    auth_views.PasswordResetDoneView.as_view(template_name='accounts/reset_password_sent.html'), 
    name='password_reset_done'),
    path('accounts/reset/<uidb64>/<token>/', 
    auth_views.PasswordResetConfirmView.as_view(template_name='accounts/reset_password_form.html'), 
    name='password_reset_confirm'),
    path('accounts/reset/done/', 
    auth_views.PasswordResetCompleteView.as_view(template_name='accounts/reset_password_done.html'), 
    name='password_reset_complete'),

]