from django.test import TestCase
from django.contrib.auth.models import User
from django.contrib.auth import authenticate

#Creamos esta prueba para probar la vista que genera la página principal y verificar que funcione sin errores.
class ViewsTestCase(TestCase):
    def test_index_loads_properly(self):
        """La página de inicio se carga correctamente"""
        response = self.client.get('http://127.0.0.1:8000')
        self.assertEqual(response.status_code, 200)


class UserTest(TestCase):
    def setUp(self):
        user = User(
            username='testeo',
            first_name='Testing',
            last_name='Testingu',
            email='testing_login@cosasdedevs.com',
            )
        user.set_password('efazo')
        user.save()

    #En esta prueba verificamos que los datos del usuario creado sean los correctos.
    def test_correct(self):
        user = authenticate(username='testeo', password='efazo')
        self.assertTrue((user is not None) and user.is_authenticated)

    #En esta prueba verificamos si el nombre es incorrecto entonces regresaría un False.
    def test_wrong_username(self):
        user = authenticate(username='wrong', password='efazo')
        self.assertFalse(user is not None and user.is_authenticated)

    #En esta prueba verificamos que si el password es incorrecto entonces regresaría un Flase.
    def test_wrong_pssword(self):
        user = authenticate(username='testeo', password='wrong')
        self.assertFalse(user is not None and user.is_authenticated)