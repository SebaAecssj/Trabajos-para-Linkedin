Tengo miedo, ayuda. ----Jasson
Aiuaaaa. ----Sebastian

22/10/2020 inicio y termino Arreglo de referencias de paginas --- Sebastian Escobar

26/10/2020 inicio y termino Creacion de Galeria de imagenes y filtros en Django --- Sebastian Escobar

28/10/2020 inicio(29/10/2020, termino) Creacion de Login y Registro --- Jasson Aros

29/10/2020 Inicio de creacion de CRUD --- Sebastian Escobar

30/10/2020 Termino de CRUD --- Sebastian Escobar

01/11/2020 inicio (02/11/2020 termino) Restablecer contraseña --- Jasson

02/11/2020 Inicio y Termino de permisos y validaciones de Usuarios-- Seba

10/11/2020 Inicio de Creacion login con google-- Seba

11/11/2020 Termino de Creacion login con google-- Sebastian Escobar

1/12/2020 Inicio incorporacion API para creacion de Usarios-- Seba

1/12/2020 Termino incorporacion API para creacion de Usarios-- Seba

3/12/2020 Inicio y Termino service worker

05/12/2020 por fin terminamos AAAAAAAAAA -jasson aros